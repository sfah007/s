<?php

namespace App\Http\Controllers;

use App\Course;
use App\Batch;
use App\Student;
use App\Task;
use Illuminate\Http\Request;

class CourseController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        $courses = Course::all();
        return view('course/view_courses')->with('courses',$courses);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('course/create_course');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
            $new_course = new Course;
            $name = $request->name;
            $name = strtoupper($name);
            $session = $request->session;
            $new_course->name = $name.' - '.$session;
            $new_course->description = $request->description;
            $new_course->fee = $request->fee;
            $new_course->duration = $request->duration;
            $new_course->status = $request->status;
            $new_course->save();
            $courses = Course::all();
            return view('course/view_courses')->with('courses',$courses);
    }


    public function delete($id)
    {
        $course  = Course::find($id);
        $batch = Batch::where('course_name',$course->name);
        $student = Student::where('course_name',$course->name);
        $task=Task::where('course_name',$course->name);
        $batch->delete();
        $student->delete();
        $course->delete();
        $task->delete();
        $courses = Course::all();
        return view('course/view_courses')->with('courses',$courses);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Course  $course
     * @return \Illuminate\Http\Response
     */
    public function show(Course $course)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Course  $course
     * @return \Illuminate\Http\Response
     */
    public function edit(Course $course)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Course  $course
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Course $course)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Course  $course
     * @return \Illuminate\Http\Response
     */
    public function destroy(Course $course)
    {
        //
    }
}
