@extends('layouts.master')

@section('body')
<div class="right_col" role="main" align="center">
	<img align="center" src={{ asset('images/logo.png') }} height="50%" width="50%">
          
</div>
@endsection
